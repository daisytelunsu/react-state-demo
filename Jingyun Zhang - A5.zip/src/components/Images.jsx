const Images = {
    moviePoster1: require('../assets/images/minions-the-rise-of-gru.jpg').default,
    moviePoster2: require('../assets/images/movie-poster2.jpg').default,
}

export default Images;